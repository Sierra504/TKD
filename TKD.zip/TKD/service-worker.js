const cacheName = "tkdPWA-v2.25.01.27";
const appShellFiles = [
  '/',
  '/index.html',
  '/manifest.json',
  '/service-worker.js',
  '/tkd.css',
  '/tkd.js',
  '/images/screenshot1.png',
  '/images/screenshot2.png'
];
self.addEventListener("install", (e) => {
  console.log("[Service Worker] Install");
  e.waitUntil(
    (async () => {
      const cache = await caches.open(cacheName);
      console.log("[Service Worker] Caching all: app shell and content");
      await cache.addAll(appShellFiles);
    })(),
  );
});

self.addEventListener("activate", (e) => {
  console.log("[Service Worker] Activate");
  e.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames.map((name) => {
          if (name !== cacheName) {
            console.log(`[Service Worker] Deleting old cache: ${name}`);
            return caches.delete(name);
          }
        })
      );
    })()
  );
});

self.addEventListener("fetch", (e) => {
  e.respondWith(
    (async () => {
      // Check if the request is in the cache
      const cachedResponse = await caches.match(e.request);
      console.log(`[Service Worker] Fetching resource: ${e.request.url}`);

      // If cached, return the cached response
      if (cachedResponse) {
        return cachedResponse;
      }

      // If not in cache, fetch from the network
      const response = await fetch(e.request);

      // Open the cache and store the new resource
      const cache = await caches.open(cacheName);
      console.log(`[Service Worker] Caching new resource: ${e.request.url}`);
      cache.put(e.request, response.clone());

      return response;
    })()
  );
});

