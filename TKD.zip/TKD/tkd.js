if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./service-worker.js")
        .then(function (registration) {
            console.log("Service Worker registered with scope: ", registration.scope);
        })
        .catch(function (error) {
            console.error("Service Worker registration failed: ", error);
        });
}

///////////////FULLSCREEN    
const checkbox = document.getElementById("fullscreen");
const pantallaCompleta = document.querySelector("html");

// Ensure the checkbox reflects the fullscreen state on page load
if (isFullscreen()) {
    checkbox.checked = true; // Start in "compress" state if already in fullscreen
} else {
    checkbox.checked = false;
}

// Helper function to check fullscreen state
function isFullscreen() {
    return document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
}

// Function to enter fullscreen
function enterFullscreen() {
    if (pantallaCompleta.requestFullscreen) {
        pantallaCompleta.requestFullscreen();
    } else if (pantallaCompleta.mozRequestFullScreen) {
        pantallaCompleta.mozRequestFullScreen();
    } else if (pantallaCompleta.webkitRequestFullscreen) {
        pantallaCompleta.webkitRequestFullscreen();
    } else if (pantallaCompleta.msRequestFullscreen) {
        pantallaCompleta.msRequestFullscreen();
    }
}

// Function to exit fullscreen
function exitFullscreen() {
    if (document.exitFullscreen) {
        document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
        document.msExitFullscreen();
    }
}

// Event listeners for fullscreen changes to sync checkbox state
function handleFullscreenChange() {
    if (!isFullscreen()) {
        checkbox.checked = false; // Uncheck when exiting fullscreen
    }
}

// Listen for all relevant fullscreen change events
document.addEventListener("fullscreenchange", handleFullscreenChange);
document.addEventListener("webkitfullscreenchange", handleFullscreenChange);
document.addEventListener("mozfullscreenchange", handleFullscreenChange);
document.addEventListener("msfullscreenchange", handleFullscreenChange);

// Event listener for checkbox to toggle fullscreen
checkbox.addEventListener("change", () => {
    if (checkbox.checked) {
        enterFullscreen(); // Enter fullscreen when checked
    } else {
        exitFullscreen(); // Exit fullscreen when unchecked
    }
});

//Variables
let roundTiempo = 10;
let incrementoPuntos = 1;
let puntosAzul = 0;
let puntosRojo = 0;
let reduccionesRojo = 0;
let reduccionesAzul = 0;
let roundBlue = 0;
let roundRed = 0;
let numeroRound = 1;
let tiempoRestante;
let timerInterval = null;
let roundActive = false;
let diferenciaMax = 12;
let numRoundsMax = 3;
let pausa;
let pausaState = 0;
let roundResults = new Array(numRoundsMax).fill(0).map(() => new Array(4).fill(0));

let table = document.getElementById('tablaResultadosDisplay');

let botonRojo = document.querySelector('.rojoContenedor');
let botonAzul = document.querySelector('.azulContenedor');

let botonAzulAmonestaciones = document.querySelector('.amonestacionesAzul');
let botonRojoAmonestaciones = document.querySelector('.amonestacionesRojo');

function checkWin() {
    return numeroRound > numRoundsMax || roundBlue >= 2 || roundRed >= 2;
}

function empezarRonda() {
    if (checkWin()) {



        reStartGame();
        return;
    } 

    if (roundActive == true && pausaState == 0) {
        document.querySelector('button').textContent = "Pausa";
        pausarTimer();
        return;
    } else if (roundActive == true && pausaState == 1) {
        continuarTimer();
        return;
    }

    document.querySelector('.seccionCentral h1').textContent = "TKD";
    roundActive = true;
    roundTiempo = parseInt(document.getElementById('roundTiempo').value, 10);
    tiempoRestante = roundTiempo;
    incrementoPuntos = parseInt(document.getElementById('incrementoPuntos').value, 10);
    updateTimer();
    agregarEventListeners();
    navigator.vibrate(500);
}

function updateTimer() {
    if (pausaState == 1) {
        return;
    }
    const timerDisplay = document.querySelector('button');
    if (timerInterval) {
        timerInterval = null;
    }
    timerInterval = setInterval(() => {
        // Decrement the remaining time
        tiempoRestante--;
        if (tiempoRestante < 0) {
            // Stop the timer when time runs out // Reset the timer variable
            terminarRonda(); // End the round when time runs out

        } else {
            // Calculate minutes and seconds from remaining time
            const minutes = Math.floor(tiempoRestante / 60).toString().padStart(2, '0');
            const seconds = (tiempoRestante % 60).toString().padStart(2, '0');
            // Update the timer display
            timerDisplay.textContent = `${minutes}:${seconds}`;
        }
    }, 1000);
}

function pausarTimer() {
    pausaState = 1;
    pausa = tiempoRestante;
    clearInterval(timerInterval);
    timerInterval = null;
    cleanEventListeners();
}
function continuarTimer() {
    pausaState = 0;
    tiempoRestante = pausa;
    updateTimer();
    agregarEventListeners();
}

function handlePointEvent(isRed, event) {
    event.preventDefault();
    countPoints(isRed);
}

function handleAmonestacionEvent(isRed, event) {
    event.preventDefault();
    contarAmonestaciones(isRed);
}

function keyDownListener(e) {
    if (!roundActive) return; // Only handle key events when the round is active
    if (e.key === "ArrowLeft") {
        // Left Arrow Key -> Red gets a point
        countPoints(true);
    } else if (e.key === "ArrowRight") {
        // Right Arrow Key -> Blue gets a point
        countPoints(false);
    }
}

function countPoints(esRojo) {
    if (!roundActive) return;
    if (esRojo) {
        if (puntosRojo + incrementoPuntos - puntosAzul < diferenciaMax || puntosRojo + incrementoPuntos == 100)  {
            puntosRojo += incrementoPuntos;
        } else {
            puntosRojo += incrementoPuntos;
            terminarRonda();
        }
    } else {
        if (puntosAzul + incrementoPuntos - puntosRojo < diferenciaMax || puntosRojo + incrementoPuntos == 100) {
            puntosAzul += incrementoPuntos;
        } else {
            puntosAzul += incrementoPuntos;
            terminarRonda();

        }
    }
    updateUI();
    navigator.vibrate(50);
}

function contarAmonestaciones(esRojo) {
    if (!roundActive) return;
    if (esRojo) {
        if ((reduccionesRojo + 1) < 5) {
            puntosRojo -= 1;
            reduccionesRojo += 1;
        } else {
            puntosRojo -= 1;
            reduccionesRojo += 1;
            terminarRonda();
        }
    } else {
        if ((reduccionesAzul + 1) < 5) {
            puntosAzul -= 1;
            reduccionesAzul += 1;
        } else {
            puntosAzul -= 1;
            reduccionesAzul += 1;
            terminarRonda();
        }
    }
    updateUI();
    navigator.vibrate(70);
}

function terminarRonda() {
    tiempoRestante = roundTiempo;
    clearInterval(timerInterval);
    timerInterval = null;
    roundActive = false;
    document.querySelector('button').textContent = "ReStart";

    roundResults[numeroRound - 1][0] = reduccionesRojo;
    roundResults[numeroRound - 1][1] = puntosRojo;
    roundResults[numeroRound - 1][2] = puntosAzul;
    roundResults[numeroRound - 1][3] = reduccionesAzul;



    if (puntosRojo > puntosAzul) {
        roundRed++;
    }
    else if (puntosRojo < puntosAzul) {
        roundBlue++;
    } else if (reduccionesAzul < reduccionesRojo) {
        roundBlue++;

    } else if (reduccionesRojo < reduccionesAzul) {
        roundRed++;
    }
    //////////
    puntosRojo = 0;
    puntosAzul = 0;
    reduccionesRojo = 0;
    reduccionesAzul = 0;
    numeroRound++;



    ///////////
    if (checkWin()) {
        if (roundBlue > roundRed) {
            document.querySelector('.seccionCentral h1').textContent = "Azul";
            
        } else if (roundBlue < roundRed) {
            document.querySelector('.seccionCentral h1').textContent = "Rojo";
            
        } else {
            document.querySelector('.seccionCentral h1').textContent = "Emp";
        }
    }



    updateUI();
    cleanEventListeners();
    navigator.vibrate(500);

}

function agregarEventListeners() {

    document.addEventListener('keydown', keyDownListener);

    handlePointEventRed = handlePointEvent.bind(null, true);
    handlePointEventBlue = handlePointEvent.bind(null, false);
    handleAmonestacionEventRed = handleAmonestacionEvent.bind(null, true);
    handleAmonestacionEventBlue = handleAmonestacionEvent.bind(null, false);

    botonAzul.addEventListener('click', handlePointEventBlue);
    botonRojo.addEventListener('click', handlePointEventRed);
    botonAzul.addEventListener('touchstart', handlePointEventBlue);
    botonRojo.addEventListener('touchstart', handlePointEventRed);

    botonAzulAmonestaciones.addEventListener('click', handleAmonestacionEventBlue);
    botonRojoAmonestaciones.addEventListener('click', handleAmonestacionEventRed);
    botonRojoAmonestaciones.addEventListener('touchstart', handleAmonestacionEventRed);
    botonAzulAmonestaciones.addEventListener('touchstart', handleAmonestacionEventBlue);


}

function cleanEventListeners() {
    document.removeEventListener('keydown', keyDownListener);

    botonAzul.removeEventListener('click', handlePointEventBlue);
    botonRojo.removeEventListener('click', handlePointEventRed);
    botonAzul.removeEventListener('touchstart', handlePointEventBlue);
    botonRojo.removeEventListener('touchstart', handlePointEventRed);


    botonAzulAmonestaciones.removeEventListener('click', handleAmonestacionEventBlue);
    botonRojoAmonestaciones.removeEventListener('click', handleAmonestacionEventRed);
    botonRojoAmonestaciones.removeEventListener('touchstart', handleAmonestacionEventRed);
    botonAzulAmonestaciones.removeEventListener('touchstart', handleAmonestacionEventBlue);

}

function updateUI() {
    document.getElementById('puntosRojo').textContent = puntosRojo;
    document.getElementById('puntosAzul').textContent = puntosAzul;
    document.getElementById('reduccionesRojo').textContent = reduccionesRojo;
    document.getElementById('reduccionesAzul').textContent = reduccionesAzul;
    document.getElementById('numeroRound').textContent = numeroRound;

    for (let i = 0; i < roundResults.length; i++) {
        for (let j = 0; j < roundResults[i].length; j++) {
            // Dynamically create the element ID using i and j
            const roundResultElement = document.getElementById(`roundResults_${i}_${j}`);

            if (roundResultElement) {
                // Update the content of the corresponding element
                roundResultElement.textContent = roundResults[i][j];
            }
        }
    }

}

function reStartGame() {
    roundResults = new Array(numRoundsMax).fill(0).map(() => new Array(4).fill(0));
    puntosRojo = 0;
    puntosAzul = 0;
    reduccionesRojo = 0;
    reduccionesAzul = 0;
    roundBlue = 0;
    roundRed = 0;
    numeroRound = 1;
    tiempoRestante = roundTiempo;
    roundActive = false;
    updateUI();
    cleanEventListeners();
    document.getElementById('ComenzarRonda').disabled = false;
    navigator.vibrate(500);
}

window.addEventListener('load', function () {
    updateUI();
});


document.getElementById('ComenzarRonda').addEventListener('click', empezarRonda)
